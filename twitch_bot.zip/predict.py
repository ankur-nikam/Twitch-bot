
from keras.models import load_model
from keras.preprocessing.sequence import pad_sequences
from keras.preprocessing.text import Tokenizer
import tensorflow as tf
import label_data
global graph
#graph = tf.get_default_graph()
model_pre = 'bi-lstmchar256256128.h5'
model = load_model(model_pre)

def prepare_url(url):

    urlz = label_data.main()

    samples = []
    labels = []
    for k, v in urlz.items():
        samples.append(k)
        labels.append(v)

    #print(len(samples))
    #print(len(labels))

    maxlen = 128
    max_words = 20000

    tokenizer = Tokenizer(num_words=max_words, char_level=True)
    tokenizer.fit_on_texts(samples)
    sequences = tokenizer.texts_to_sequences(url)
    word_index = tokenizer.word_index
    #print('Found %s unique tokens.' % len(word_index))

    url_prepped = pad_sequences(sequences, maxlen=maxlen)
    return url_prepped


def predict(url):
    urlz = []


    urlz.append(url)
    print(url)

    # Process and prepare the URL.
    url_prepped = prepare_url(urlz)

    # classify the URL and make the prediction.
    #with graph.as_default():
    prediction = model.predict(url_prepped)
    print(prediction)
    if prediction > 0.70:
        return 1
    else:
        return 0